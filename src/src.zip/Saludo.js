import React, { Component } from 'react';
 
class Saludo extends Component {
  render() {
    return (
      <h1>
        Hola Mundo!
      </h1>
    );
  }
}
 
export default Saludo;